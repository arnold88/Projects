Obey Cat 2.51

Obey Cat and is a demonstration program.
It demonstrates RCode and RCode Plus.

The RCR library (version 2.51.02) must be in \CUSTOM\RCRLIB.R

It also gives provides a Master Studio personality and structure for building more complicated personalities.

See http://aibohack.com/2or3/obeycat.htm for instructions.

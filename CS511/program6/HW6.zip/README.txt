
Arnold Lee
CS 511 HW #6

3x4 Maze non-deterministic learning agent
Read me file

Attached: AgentFunction.java

Algorithm:
- Using equation 21.5 and build it in a function that updates utilities on the go
- Compare all utilites on cells around the agent location, elect a best action based
on the highest utlity score


Main issues:
-For 30 trials or above this thing runs particulary slow or appear unresponsive



Results:

These are what it looks like at trial 20 at one point:

*******************************************************************

Trial 20 score: 0.6799999999999999
Trial 20 score: 0.8484929584919491

Total Score: 17.29951515
Average Score: 0.8649

-------------Utility of each state-----------------------------------------------------
 | 0.4 | 0.69 | 0.75 | 0.86 | 
------------------------------------------------------------------------------
 | 0.63 | 0.27 | 0.59 | 0.42 | 
------------------------------------------------------------------------------
 | 0.41 | 0.35 | 0.46 | 0.32 | 
------------------------------------------------------------------------------

-------------Optimal Policy-----------------------------------------------------
 | > | A | > | < | 
-----------------------------------------
 | > | < | > | A | 
-----------------------------------------
 | > | < | > | V | 
-----------------------------------------

Finished.

************************************************************************

The trial score indicates the average utility at the given point of time during that trial.
The total score is the sum of the trial score for all trials.
The average score is the average of total score across all trials.

The utility map indicates your expected utlity at the given square, at that trial.

Optimal policy suggest which direction you should go if you are in one of the cells. "A" is going north, > is going east, "V" is going south, and < is going west.

Enjoy!
